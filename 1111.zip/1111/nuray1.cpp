#include <iostream>
#include <vector>
#include <fstream>
#include <thread>
#include <chrono>
#include <cstring>
#include <algorithm>
#include <random>

const int AES_BLOCK_SIZE = 16; // Размер блока AES (16 байт)
const int N = 10; // Количество матриц для обработки

// Фиксированная матрица для MixColumns в AES
const uint8_t mixMatrix[4][4] = {
    {0x02, 0x03, 0x01, 0x01},
    {0x01, 0x02, 0x03, 0x01},
    {0x01, 0x01, 0x02, 0x03},
    {0x03, 0x01, 0x01, 0x02}
};

// Функция умножения в поле Галуа
uint8_t gmul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    while (b) {
        if (b & 1) p ^= a;
        bool highBit = a & 0x80;
        a <<= 1;
        if (highBit) a ^= 0x1b; // Полином x^8 + x^4 + x^3 + x + 1
        b >>= 1;
    }
    return p;
}

// Функция MixColumns для одной матрицы
void mixColumns(std::vector<std::vector<uint8_t>>& state) {
    std::vector<std::vector<uint8_t>> temp(4, std::vector<uint8_t>(4));
    
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 4; ++row) {
            temp[row][col] = gmul(state[0][col], mixMatrix[row][0]) ^
                             gmul(state[1][col], mixMatrix[row][1]) ^
                             gmul(state[2][col], mixMatrix[row][2]) ^
                             gmul(state[3][col], mixMatrix[row][3]);
        }
    }

    state = temp; // Копируем результат обратно в состояние
}

// Функция для обработки матриц
void processMatrices(const std::vector<std::vector<std::vector<uint8_t>>>& matrices, int index, std::ofstream& outputFile) {
    std::vector<std::vector<uint8_t>> state = matrices[index];
    mixColumns(state);

    // Запись результата в файл
    outputFile << "Matrix " << index + 1 << " after MixColumns:\n";
    for (const auto& row : state) {
        for (const auto& byte : row) {
            outputFile << static_cast<int>(byte) << " "; // Запись в десятичном формате
        }
        outputFile << "\n";
    }
    outputFile << "\n";
}

// Функция для генерации матриц с случайными значениями
std::vector<std::vector<std::vector<uint8_t>>> generateMatrices(int count) {
    std::vector<std::vector<std::vector<uint8_t>>> matrices;
    std::random_device rd;  // Получаем случайное начальное значение
    std::mt19937 gen(rd()); // Генератор случайных чисел
    std::uniform_int_distribution<uint8_t> dis(0, 255); // Распределение от 0 до 255

    for (int i = 0; i < count; ++i) {
        std::vector<std::vector<uint8_t>> matrix(4, std::vector<uint8_t>(4));
        // Заполнение матрицы случайными значениями
        for (int row = 0; row < 4; ++row) {
            for (int col = 0; col < 4; ++col) {
                matrix[row][col] = dis(gen);
            }
        }
        matrices.push_back(matrix);
    }
    return matrices;
}

// Функция для записи матриц в файл
void saveMatricesToFile(const std::vector<std::vector<std::vector<uint8_t>>>& matrices, const std::string& filename) {
    std::ofstream inputFile(filename);
    if (!inputFile.is_open()) {
        std::cerr << "Ошибка открытия файла для записи начальных матриц!" << std::endl;
        return;
    }

    for (int i = 0; i < matrices.size(); ++i) {
        inputFile << "Matrix " << i + 1 << ":\n";
        for (const auto& row : matrices[i]) {
            for (const auto& byte : row) {
                inputFile << static_cast<int>(byte) << " "; // Запись в десятичном формате
            }
            inputFile << "\n";
        }
        inputFile << "\n";
    }

    inputFile.close();
}

int main(int argc, char* argv[]) {
    // Генерация данных
    auto matrices = generateMatrices(N);
    
    // Сохранение начальных данных в файл
    saveMatricesToFile(matrices, "initial_matrices.txt");

    // Открытие файла для записи результатов
    std::ofstream outputFile("results.txt");
    if (!outputFile.is_open()) {
        std::cerr << "Ошибка открытия файла для записи результатов!" << std::endl;
        return 1;
    }

    // Параллельная обработка
    std::vector<std::thread> threads;
    for (int i = 0; i < matrices.size(); ++i) {
        threads.emplace_back(processMatrices, matrices, i, std::ref(outputFile));
    }
    for (auto& thread : threads) {
        thread.join();
    }

    // Закрытие файла
    outputFile.close();
    return 0;
}
